﻿namespace DnD_Kostky
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkedListBoxDice = new System.Windows.Forms.CheckedListBox();
            this.btnCreateNewDice = new System.Windows.Forms.Button();
            this.btnRollDice = new System.Windows.Forms.Button();
            this.panelRolls = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // checkedListBoxDice
            // 
            this.checkedListBoxDice.FormattingEnabled = true;
            this.checkedListBoxDice.Location = new System.Drawing.Point(12, 12);
            this.checkedListBoxDice.Name = "checkedListBoxDice";
            this.checkedListBoxDice.Size = new System.Drawing.Size(262, 382);
            this.checkedListBoxDice.TabIndex = 0;
            // 
            // btnCreateNewDice
            // 
            this.btnCreateNewDice.Location = new System.Drawing.Point(674, 12);
            this.btnCreateNewDice.Name = "btnCreateNewDice";
            this.btnCreateNewDice.Size = new System.Drawing.Size(114, 23);
            this.btnCreateNewDice.TabIndex = 1;
            this.btnCreateNewDice.Text = "Create a new Dice";
            this.btnCreateNewDice.UseVisualStyleBackColor = true;
            this.btnCreateNewDice.Click += new System.EventHandler(this.btnCreateNewDice_Click);
            // 
            // btnRollDice
            // 
            this.btnRollDice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRollDice.Location = new System.Drawing.Point(12, 408);
            this.btnRollDice.Name = "btnRollDice";
            this.btnRollDice.Size = new System.Drawing.Size(262, 30);
            this.btnRollDice.TabIndex = 2;
            this.btnRollDice.Text = "Roll Dice";
            this.btnRollDice.UseVisualStyleBackColor = true;
            this.btnRollDice.Click += new System.EventHandler(this.btnRollDice_Click);
            // 
            // panelRolls
            // 
            this.panelRolls.Location = new System.Drawing.Point(280, 12);
            this.panelRolls.Name = "panelRolls";
            this.panelRolls.Size = new System.Drawing.Size(288, 382);
            this.panelRolls.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panelRolls);
            this.Controls.Add(this.btnRollDice);
            this.Controls.Add(this.btnCreateNewDice);
            this.Controls.Add(this.checkedListBoxDice);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private CheckedListBox checkedListBoxDice;
        private Button btnCreateNewDice;
        private Button btnRollDice;
        private Panel panelRolls;
    }
}