namespace ZamestnanciSestavy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGenerateRandomData_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            string[] jmena = {
    "Marie", "Marcela", "Jan", "Petr", "Ji��", "Dagmar", "Karel", "Josef", "Zden�k",
    "Pavla", "Aneta", "Dana", "Leopold", "Richard", "Stanislav", "Miroslav", "Pavel",
    "Jaroslava", "V�ra", "Hana", "Bronislava", "Jaroslav", "Ludmila", "Radek", "Vlasta",
    "Lucie", "Vlastimil", "Miroslava", "Anna", "Lenka", "Antonie", "V�clav", "Ond�ej",
    "Jana", "Miloslav", "Daniel", "Zdenka", "Jitka", "Luk�", "Franti�ek", "Libu�e",
    "Tom�", "Josefa", "David", "Helena", "Nikolay", "Vladim�r", "�tefanie", "Kate�ina", "Martin"
};
            string[] prijmeni = {
    "Hude�kov�", "Pol�kov�", "Kop�iva", "Goli�", "Salava", "Truchl�", "Z�ka", "Peterka", "Lisn�k",
    "Sychrov�", "P�chov�", "�vejdov�", "Tjasko", "Z�horec", "Kub�t", "Hoke�", "Tr�vn��ek",
    "�vr�kov�", "Vtelensk�", "Hekrdlov�", "Pot��kov�", "Moric", "Uh�rkov�", "Urb�nek", "Prchl�kov�",
    "Mato�kov�", "Cenker", "Bezd�kov�", "N�mcov�", "Riegerov�", "Szabov�", "Pe�ek", "Mal��k",
    "Divi�ov�", "Frydrych", "Li�ka", "Janotov�", "�ervinkov�", "P�ibyl�k", "Svoboda", "�vejd�kov�",
    "Hrab�k", "Jir�nkov�", "Paloc", "Pr�chov�", "Konvalinka", "Hala", "Sklensk�", "�e�otkov�", "Le�"
};

            for (int i = 0; i < 50; i++)
            {
                listBoxZamestnanci.Items.Add(
                    new Zamestnanec(jmena[random.Next(50)],
                                    prijmeni[random.Next(50)],
                                    random.Next(0, 24),
                                    random.NextDouble() < 0.2)
                    );
            }
        }

        private void btnTop5Zamestnancu_Click(object sender, EventArgs e)
        {
            List<Zamestnanec> topZ = listBoxZamestnanci.Items
                .Cast<Zamestnanec>()
                .OrderByDescending(x => x.PocetHodin)
                .Take(5)
                .ToList();

            MessageBox.Show(String.Join("\r\n", topZ));
        }

        private void btnVedouci_Click(object sender, EventArgs e)
        {
            List<Zamestnanec> vedouci = listBoxZamestnanci.Items
                .Cast<Zamestnanec>()
                .Where(x => x.JeVedouci)
                .ToList();

            MessageBox.Show(String.Join("\r\n", vedouci));
        }

        private void btnAboveAverage_Click(object sender, EventArgs e)
        {
            double average = 0;
            foreach (Zamestnanec z in listBoxZamestnanci.Items) { average += z.PocetHodin; }
            average /= listBoxZamestnanci.Items.Count;

            List<Zamestnanec> frajeri = listBoxZamestnanci.Items
                .Cast<Zamestnanec>()
                .Where(x => x.PocetHodin > average)
                .ToList();

            MessageBox.Show(String.Join("\r\n", frajeri));
        }

        private void btnSummary_Click(object sender, EventArgs e)
        {

            throw new NotImplementedException();
        }
    }
}