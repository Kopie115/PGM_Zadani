namespace DnD_Kostky
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<int> throws = new List<int>();

        private void btnCreateNewDice_Click(object sender, EventArgs e)
        {
            FormCreateDice formCreateDice = new FormCreateDice();
            if(formCreateDice.ShowDialog() == DialogResult.OK)
            {
                int sides = formCreateDice.Sides;
                Color color = formCreateDice.Color;
                string label = formCreateDice.Label;

                Dice dice = new Dice(sides, color, label);
                checkedListBoxDice.Items.Add(dice);
            }
        }
        private void btnRollDice_Click(object sender, EventArgs e)
        {
            panelRolls.Controls.Clear();
            for(int i = 0; i < checkedListBoxDice.CheckedItems.Count; i++)
            {
                Dice dice = (Dice)checkedListBoxDice.CheckedItems[i];

                // dice render
                Label labelDice = new Label();
                labelDice.Font = new Font("Arial", 12);
                labelDice.Location = new Point(0, i * 20);
                labelDice.BackColor = dice.Color;
                labelDice.ForeColor = GetReadableTextColor(labelDice.BackColor); // to ensure number is readable on the dice
                labelDice.Text = dice.Roll()
                                 .ToString();
                labelDice.AutoSize = true;
                panelRolls.Controls.Add(labelDice);

                // dice label
                Label labelLabel = new Label();
                labelLabel.Font = new Font("Arial", 12);
                labelLabel.Location = new Point(labelDice.Location.X + labelDice.Size.Width + 5, labelDice.Location.Y);
                labelLabel.Text = dice.Label;
                labelLabel.AutoSize = true;
                panelRolls.Controls.Add(labelLabel);
            }

            /*
            lblRolls.Text = "";
            foreach(Dice dice in checkedListBoxDice.CheckedItems)
            {
                lblRolls.Text += $"{dice}: {dice.Roll()}\r\n";
            }*/
        }

        private Color GetReadableTextColor(Color bg)
        {
            int brightness = (int)((bg.R * 299 + bg.G * 587 + bg.B * 114) / 1000);
            return brightness > 128 ? Color.Black : Color.White;
        }


    }
}