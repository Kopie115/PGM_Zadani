﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DnD_Kostky
{
    internal class Dice
    {
        private int sides;
        private Color color;
        private string label;

        /// <summary>
        /// Dice musts have at least 4 sides, any number <4 will set the sides count to 4
        /// </summary>
        public int Sides { get { return sides; } set { sides = Math.Max(4, value); } } 
        public Color Color { get { return color; } set { color = value; } }
        public string Label { get { return label; } set { label = value; } }

        /// <summary>
        /// Creates a Dice
        /// </summary>
        /// <param name="sides">Amount of sides = maximum rollable number</param>
        /// <param name="color">Dice color</param>
        /// <param name="label"></param>
        public Dice(int sides, Color color, string label)
        {
            Sides = sides;
            Color = color;
            Label = label;
        }

        /// <summary>
        /// Rolls the dice
        /// </summary>
        /// <returns>a random number from 1 to number of sides</returns>
        public int Roll() { return new Random().Next(1, sides + 1); }
        public override string ToString()
        {
            return $"{color} dice {label} (1-{sides})";
        }
    }
}
