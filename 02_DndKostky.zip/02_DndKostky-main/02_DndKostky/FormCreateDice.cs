﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DnD_Kostky
{
    public partial class FormCreateDice : Form
    {
        public FormCreateDice()
        {
            InitializeComponent();
            colorDialog1.Color = Color.White;
            this.BackColor = Color.White;
        }
        private void btnPickColor_Click(object sender, EventArgs e)
        {
            if(colorDialog1.ShowDialog() == DialogResult.OK)
            {
                Color color = colorDialog1.Color;
                this.BackColor = color;
            }
        }

        public int Sides { get { return (int)numSides.Value; } }
        public Color Color { get { return colorDialog1.Color; } }
        public string Label { get { return txtLabel.Text; } }



        //dialog results
        private void btnOK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

    }
}
