﻿namespace DnD_Kostky
{
    partial class FormCreateDice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numSides = new System.Windows.Forms.NumericUpDown();
            this.lblSides = new System.Windows.Forms.Label();
            this.lblColor = new System.Windows.Forms.Label();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.btnPickColor = new System.Windows.Forms.Button();
            this.lblLabel = new System.Windows.Forms.Label();
            this.txtLabel = new System.Windows.Forms.TextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numSides)).BeginInit();
            this.SuspendLayout();
            // 
            // numSides
            // 
            this.numSides.Location = new System.Drawing.Point(57, 7);
            this.numSides.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.numSides.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numSides.Name = "numSides";
            this.numSides.Size = new System.Drawing.Size(118, 23);
            this.numSides.TabIndex = 0;
            this.numSides.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // lblSides
            // 
            this.lblSides.AutoSize = true;
            this.lblSides.Location = new System.Drawing.Point(12, 9);
            this.lblSides.Name = "lblSides";
            this.lblSides.Size = new System.Drawing.Size(37, 15);
            this.lblSides.TabIndex = 1;
            this.lblSides.Text = "Sides:";
            // 
            // lblColor
            // 
            this.lblColor.AutoSize = true;
            this.lblColor.Location = new System.Drawing.Point(12, 36);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new System.Drawing.Size(39, 15);
            this.lblColor.TabIndex = 2;
            this.lblColor.Text = "Color:";
            // 
            // btnPickColor
            // 
            this.btnPickColor.Location = new System.Drawing.Point(57, 32);
            this.btnPickColor.Name = "btnPickColor";
            this.btnPickColor.Size = new System.Drawing.Size(118, 23);
            this.btnPickColor.TabIndex = 3;
            this.btnPickColor.Text = "Click to pick color";
            this.btnPickColor.UseVisualStyleBackColor = true;
            this.btnPickColor.Click += new System.EventHandler(this.btnPickColor_Click);
            // 
            // lblLabel
            // 
            this.lblLabel.AutoSize = true;
            this.lblLabel.Location = new System.Drawing.Point(11, 60);
            this.lblLabel.Name = "lblLabel";
            this.lblLabel.Size = new System.Drawing.Size(38, 15);
            this.lblLabel.TabIndex = 4;
            this.lblLabel.Text = "Label:";
            // 
            // txtLabel
            // 
            this.txtLabel.Location = new System.Drawing.Point(57, 57);
            this.txtLabel.Name = "txtLabel";
            this.txtLabel.Size = new System.Drawing.Size(118, 23);
            this.txtLabel.TabIndex = 5;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(12, 115);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(100, 30);
            this.btnOK.TabIndex = 6;
            this.btnOK.Text = "Create dice";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(205, 115);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 30);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // FormCreateDice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 157);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.txtLabel);
            this.Controls.Add(this.lblLabel);
            this.Controls.Add(this.btnPickColor);
            this.Controls.Add(this.lblColor);
            this.Controls.Add(this.lblSides);
            this.Controls.Add(this.numSides);
            this.Name = "FormCreateDice";
            this.Text = "Create Dice:";
            ((System.ComponentModel.ISupportInitialize)(this.numSides)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private NumericUpDown numSides;
        private Label lblSides;
        private Label lblColor;
        private ColorDialog colorDialog1;
        private Button btnPickColor;
        private Label lblLabel;
        private TextBox txtLabel;
        private Button btnOK;
        private Button btnCancel;
    }
}